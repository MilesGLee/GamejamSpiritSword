Open the exe to run the game.

Objective: You control your player and a spirit sword. You are harmless, the sword is not
Enemies will spawn forever, some will shoot projectiles that
auto aim. Last as long as you can, its really not that hard.

Controls:
WASD, Left Ctrl, and Space for player movement.

Jump ontop of the sword to ride it.

[Hold Left Shift]: Enter summoning mode, the yellow visualizer will display
where the sword will summon to, press [Left Click] to summon the sword while
in summoning mode. [Right Click] will summon to sword towards your position.

[Hold 1] Aim at enemy and press [Left Click] to target the sword to the enemy.

[Hold 2] Then click [Left Click] to target the sword at all enemies in your vision.
Carful you will lose control of the sword while it finishes off all the enemies.

[PRess 3] Generates a shield to destroy projectiles around the sword.